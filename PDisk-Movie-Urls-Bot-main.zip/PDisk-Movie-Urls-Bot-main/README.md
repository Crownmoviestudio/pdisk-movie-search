# PDisk Movie Links Bot

__This Bot for only gives you PDisk Links which you are asked Movie.__

__It is developed by [contact](https://telegram.me/DarlingAnil)..__

__Just Sent Any Text As Query It Will Search in dict And gives you exact result With The Message Links.__

##  USAGE

### __How To Use Me?__

* -> First you need to update with your pdisk movie item ids in movielinks.py in repository
* -> Deploy code with using the bot API KEY.
* -> Now you can use me as individual.
* -> I can also work in groups but first you need to make an admin.

### Pre Requisites 

* -> __You need pdisk item ids and update it with your pdisk movie name and item id.__
* -> __You need Bot API TOKEN [BotFather](https://telegram.me/BotFather)__

# Deploy
you can use this bot as your own.

<details><summary>Deploy To Heroku</summary>
<p>
<br>
<a href="https://heroku.com/deploy?template=https://github.com/Anilkumar-Bathala/PDisk-Movie-Links-Bot">
  <img src="https://www.herokucdn.com/deploy/button.svg" alt="Deploy">
</a>
</p>
</details>

## If You Have Any Queries   
Ping Me in TELEGRAM [Telegram PROFILE](https://telegram.me/DarlingAnil)

Report Bugs, Give Feature Requests There..   
Do Fork And Star The Repository If You Liked It.

## Disclaimer
[![GNU Affero General Public License v3.0](https://www.gnu.org/graphics/agplv3-155x51.png)](https://www.gnu.org/licenses/agpl-3.0.en.html#header)    
Selling The Codes To Other People For Money Is *Strictly Prohibited*.
